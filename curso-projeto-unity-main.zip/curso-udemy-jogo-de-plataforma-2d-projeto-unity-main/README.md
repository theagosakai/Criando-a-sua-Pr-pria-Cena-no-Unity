<h2>Crie um Jogo de Plataforma 2D na Unity [Curso Udemy]</h2>
Nesse repositório você encontra o projeto (com todos os arquivos) do nosso Curso "Unity: Crie um Jogo de Plataforma 2D", publicado na Udemy.
<br>
Espero que se divirta bastante e aprenda diversas coisas novas com ele :)
<br>
Para acessar o curso, <a href="https://www.udemy.com/course/unity-crie-um-jogo-de-plataforma-2d/?referralCode=43A6B0F606DF6F9EB5DC">clique aqui</a>
<br>

<a href="https://www.udemy.com/course/unity-crie-um-jogo-de-plataforma-2d/?referralCode=43A6B0F606DF6F9EB5DC">![jogo-de-plataforma-2d-miniatuta-youtube-01](https://user-images.githubusercontent.com/102618272/200945139-3e0fe1e0-edf9-4a57-b05e-4eedf75944e1.png)>/a>
